<?php
/**
 *
 * Single Directory - Tabs - Description
 *
 * @Author 		Pluginrox
 * @Copyright: 	2018 Pluginrox
 */

if ( ! defined('ABSPATH')) exit;  // if direct access

?>

<?php the_content(); ?>
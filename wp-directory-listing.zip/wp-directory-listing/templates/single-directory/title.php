<?php
/**
 *
 * Single Directory Title
 *
 * @Author 		Pluginrox
 * @Copyright: 	2018 Pluginrox
 */

if ( ! defined('ABSPATH')) exit;  // if direct access


the_title( '<h1 class="product_title entry-title">', '</h1>' );
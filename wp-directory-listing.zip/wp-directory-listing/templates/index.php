<?php

/*
* @Author 		Pluginrox
* @Folder	 	job-board-manager\themes\joblist

* Copyright: 	2018 Pluginrox
*/

if ( ! defined('ABSPATH')) exit;  // if direct access
	
	
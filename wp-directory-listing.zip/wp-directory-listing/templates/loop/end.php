<?php
/**
 * Directory Archive - Loop End
 *
 * @author        Pluginrox
 * @copyright:    2018 Pluginrox
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}  // if direct access


?>

</ul> <!-- Loop End -->
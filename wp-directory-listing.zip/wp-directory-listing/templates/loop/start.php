<?php
/**
 * Directory Archive - Loop Start
 *
 * @author        Pluginrox
 * @copyright:    2018 Pluginrox
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}  // if direct access

?>

<ul class="<?php wpdl_directory_archive_class( 'directory-archive' ); ?>">
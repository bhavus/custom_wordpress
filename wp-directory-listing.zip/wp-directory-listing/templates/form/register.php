<?php
/**
 * Form Template - Register
 *
 * @author        Pluginrox
 * @copyright     2018 Pluginrox
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}  // if direct access

$args = array(
//	'redirect' => wpdl_get_page_permalink( 'myaccount' ),
);



?>

<h2><?php esc_html_e( 'Register', TTDD ); ?></h2>

<div class="wpdl-form wpdl-form-register">

	<?php echo wp_register( ); ?>

</div>


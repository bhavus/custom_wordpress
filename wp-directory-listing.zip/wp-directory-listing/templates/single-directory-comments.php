<?php
/**
 * Comments Template
 *
 * @Author 		Pluginrox
 * @Copyright: 	2018 Pluginrox
 */

if ( ! defined( 'ABSPATH' ) ) exit;

global $directory;

if( ! comments_open() ) return;
